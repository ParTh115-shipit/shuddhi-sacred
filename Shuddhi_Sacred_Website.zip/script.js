
setTimeout(function() {
  window.location.href = "https://google.com"; // Replace with your homepage URL later
}, 2000);
